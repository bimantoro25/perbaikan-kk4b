package com.app.recyclerview_sigit

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Book(
    val imgBook: Int,
    val nameBook: String,
    val descBook: String,
) : Parcelable