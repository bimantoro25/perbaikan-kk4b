package com.app.recyclerview_sigit

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class BookAdapter(private val context: Context, private val movie: List<Book>, val listener: (Book) -> Unit)
    : RecyclerView.Adapter<BookAdapter.BookViewHolder>(){

    class BookViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val imgBook = view.findViewById<ImageView>(R.id.img_item_photo)
        val nameBook = view.findViewById<TextView>(R.id.tv_item_name)
        val descBook = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(book: Book, listener: (Book) -> Unit) {
            imgBook.setImageResource(book.imgBook)
            nameBook.text = book.nameBook
            descBook.text = book.descBook
            itemView.setOnClickListener{
                listener(book)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        return BookViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_rv, parent, false)
        )
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        holder.bindView(movie[position], listener)
    }

    override fun getItemCount(): Int = movie.size
}