package com.app.recyclerview_sigit

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bookList = listOf<Book>(
            Book(
                R.drawable.danur,
                nameBook = "Danur",
                descBook = "Horor"
            ),
            Book(
                R.drawable.dilan,
                nameBook = "Dilan",
                descBook = "Romance"
            ),
            Book(
                R.drawable.iblis,
                nameBook = "Iblis",
                descBook = "Horor"
            ),
            Book(
                R.drawable.mariposa,
                nameBook = "Mariposa",
                descBook = "Romance"
            ),
            Book(
                R.drawable.senja,
                nameBook = "Senja",
                descBook = "Romance"
            ),

        )

        val recyclerView = findViewById<RecyclerView>(R.id.rv_book)
        val horizontalLayoutManagaer =
            LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.setLayoutManager(horizontalLayoutManagaer);
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = BookAdapter(this, bookList){
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)

        }
    }
}